insert into pessoa(id,nome,cpf) values(1,'John Travolta','000.000.000-00');
insert into pessoa(id,nome,cpf) values(2,'Tom Cruise ','123.456.789-01');
