insert into pessoa(id,nome,CPF) values (1,'Tom Cruise','000.000.000-12')
insert into pessoa(id,nome,CPF) values (2,'John Travolta','000.000.000-34')